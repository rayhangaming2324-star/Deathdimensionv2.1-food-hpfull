DeathDimension V2.1 - Paper 1.21.11 | Java 21

Fixes in this source build:
- Fatal damage is intercepted so the cinematic can begin at the original location.
- Inventory, armor, and offhand are dropped at the death location before the cinematic.
- Inventory is cleared after dropping to prevent duplication.
- Cinematic duration is 100 ticks (5 seconds).
- Soul particles, levitation, blindness/darkness, title, sound, and visual lightning remain.
- Direct/plugin-triggered deaths retain the fallback respawn flow.
- Punishment commands and persistence remain.


Build:
1. Extract this ZIP.
2. Build using Java 21 and Maven: mvn clean package
3. JAR will be in target/deathdimension-2.1.0.jar


Test on a backup server first. This source has not been compiled in this environment because Maven is not installed here.
