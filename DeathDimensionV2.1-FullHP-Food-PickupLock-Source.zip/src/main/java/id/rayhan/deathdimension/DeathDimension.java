package id.rayhan.deathdimension;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;

import java.util.*;

public final class DeathDimension extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Long> punishments = new HashMap<>();
    private final Set<UUID> activeCinematics = new HashSet<>();
    private final Map<UUID, Float> oldWalkSpeeds = new HashMap<>();
    private final Map<UUID, Boolean> oldInvulnerable = new HashMap<>();
    private final Map<UUID, Location> pendingDeathLocations = new HashMap<>();
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private BukkitTask ticker;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadPunishments();
        createVoidWorld();
        Objects.requireNonNull(getCommand("deathdimension")).setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        ticker = getServer().getScheduler().runTaskTimer(this, this::tickPunishments, 20L, 20L);
        getLogger().info("DeathDimension V2 enabled.");
    }

    @Override
    public void onDisable() {
        if (ticker != null) ticker.cancel();
        savePunishments();
    }

    private void createVoidWorld() {
        String name = getConfig().getString("void.world", "death_void");
        World world = Bukkit.getWorld(name);
        if (world == null) {
            ChunkGenerator emptyGenerator = new ChunkGenerator() {
                @Override
                public ChunkData generateChunkData(World world, Random random, int x, int z, BiomeGrid biome) {
                    return createChunkData(world);
                }
            };
            world = new WorldCreator(name).environment(World.Environment.NORMAL).generator(emptyGenerator).createWorld();
        }
        if (world == null) {
            getLogger().severe("Gagal membuat world void: " + name);
            return;
        }
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setTime(18000);
        world.setStorm(false);
        world.setThundering(false);
        Location center = voidLocation();
        int radius = Math.max(1, getConfig().getInt("void.platform-radius", 3));
        Material platform;
        try {
            platform = Material.valueOf(getConfig().getString("void.platform-block", "BLACKSTONE").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            platform = Material.BLACKSTONE;
        }
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                world.getBlockAt(center.getBlockX() + x, center.getBlockY() - 1, center.getBlockZ() + z).setType(platform, false);
            }
        }
        world.setSpawnLocation(center);
    }

    private Location voidLocation() {
        World world = Bukkit.getWorld(getConfig().getString("void.world", "death_void"));
        if (world == null) return Bukkit.getWorlds().get(0).getSpawnLocation();
        return new Location(world,
                getConfig().getDouble("void.x", 0.5),
                getConfig().getDouble("void.y", 80.0),
                getConfig().getDouble("void.z", 0.5),
                0f, 0f);
    }

    // Intercept lethal damage so the cinematic begins BEFORE the player is actually dead
    // and before teleporting to death_void.
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLethalDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        UUID id = player.getUniqueId();
        if (activeCinematics.contains(id)) {
            event.setCancelled(true);
            return;
        }

        double remainingHealth = player.getHealth() + player.getAbsorptionAmount();
        if (event.getFinalDamage() < remainingHealth) return;

        event.setCancelled(true);
        beginDeathSequence(player);
    }

    private void beginDeathSequence(Player player) {
        UUID id = player.getUniqueId();
        if (!activeCinematics.add(id)) return;

        long expiry = System.currentTimeMillis()
                + getConfig().getLong("punishment-seconds", 10800) * 1000L;
        punishments.put(id, expiry);
        savePunishments();

        oldWalkSpeeds.put(id, player.getWalkSpeed());
        oldInvulnerable.put(id, player.isInvulnerable());
        player.setInvulnerable(true);
        player.setWalkSpeed(0.0f);

        // Drop inventory exactly at the death location before the cinematic starts.
        // Lethal damage is cancelled to keep the player alive for the animation.
        dropInventoryAtDeath(player);

        // Effects start at the player's current location, before the void teleport.
        showDeathStartEffects(player);
        int animationTicks = Math.max(20, getConfig().getInt("cinematic.animation-ticks", 100));
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.LEVITATION, animationTicks, 0, false, false, true));

        final int[] ticks = {0};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!player.isOnline()) {
                task.cancel();
                activeCinematics.remove(id);
                return;
            }
            spawnSoulParticles(player);
            if (getConfig().getBoolean("cinematic.lightning", true) && ticks[0] % 20 == 0) {
                // Efek petir visual saja: tidak memberi damage atau menyalakan api.
                player.getWorld().strikeLightningEffect(player.getLocation());
            }
            ticks[0] += 5;
            if (ticks[0] >= animationTicks) {
                task.cancel();
                player.removePotionEffect(PotionEffectType.LEVITATION);
                // Restore the normal HUD after the death cinematic: full health and food.
                player.setHealth(player.getMaxHealth());
                player.setFoodLevel(20);
                player.setSaturation(5.0f);
                player.setExhaustion(0.0f);
                player.teleport(voidLocation());
                player.setWalkSpeed(oldWalkSpeeds.getOrDefault(id, 0.2f));
                player.setInvulnerable(oldInvulnerable.getOrDefault(id, false));
                oldWalkSpeeds.remove(id);
                oldInvulnerable.remove(id);
                activeCinematics.remove(id);
                player.sendMessage(legacy.deserialize("&8Jiwamu telah dibawa ke Death Dimension."));
            }
        }, 0L, 5L);
    }


    private void dropInventoryAtDeath(Player player) {
        Location dropLocation = player.getLocation().clone();
        var inventory = player.getInventory();
        for (org.bukkit.inventory.ItemStack item : inventory.getStorageContents()) {
            if (item != null && !item.getType().isAir()) {
                dropUnlockedItem(dropLocation, item);
            }
        }
        for (org.bukkit.inventory.ItemStack item : inventory.getArmorContents()) {
            if (item != null && !item.getType().isAir()) {
                dropUnlockedItem(dropLocation, item);
            }
        }
        org.bukkit.inventory.ItemStack offhand = inventory.getItemInOffHand();
        if (offhand != null && !offhand.getType().isAir()) {
            dropUnlockedItem(dropLocation, offhand);
        }
        inventory.clear();
        inventory.setArmorContents(new org.bukkit.inventory.ItemStack[4]);
        inventory.setItemInOffHand(null);
    }

    // Drop items without a pickup lock; owner is unset so any player can pick them up.
    private void dropUnlockedItem(Location location, org.bukkit.inventory.ItemStack stack) {
        org.bukkit.entity.Item dropped = location.getWorld().dropItemNaturally(location, stack.clone());
        dropped.setPickupDelay(0);
        dropped.setOwner(null);
        dropped.setThrower(null);
    }

    // Pemain yang sedang menjalani cinematic tidak dapat mengambil kembali item dropnya.
    // Pemain lain tetap dapat mengambil item tersebut; pembatasan hanya berlaku pada pemain ini.
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPickupDuringCinematic(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player
                && activeCinematics.contains(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }


    // Fallback untuk kematian yang dipicu plugin lain (misalnya setHealth(0)).
    // Pemain di-respawn otomatis, dikembalikan ke lokasi kematian, lalu animasi 5 detik dimulai.
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID id = player.getUniqueId();
        if (activeCinematics.contains(id)) return;

        Location deathLocation = player.getLocation().clone();
        pendingDeathLocations.put(id, deathLocation);

        long expiry = System.currentTimeMillis()
                + getConfig().getLong("punishment-seconds", 10800) * 1000L;
        punishments.put(id, expiry);
        savePunishments();

        // Jangan biarkan layar You Died/Respawn/Title Screen menetap.
        if (getConfig().getBoolean("cinematic.auto-respawn", true)) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline() && player.isDead()) {
                    try {
                        player.spigot().respawn();
                    } catch (Throwable ex) {
                        getLogger().warning("Auto-respawn gagal; periksa kompatibilitas Paper.");
                    }
                }
            }, 1L);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        Location deathLocation = pendingDeathLocations.remove(id);
        if (deathLocation != null) {
            event.setRespawnLocation(deathLocation);
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline()) beginDeathSequence(player);
            }, 1L);
            return;
        }
        if (punishments.containsKey(id)) {
            event.setRespawnLocation(voidLocation());
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline()) player.teleport(voidLocation());
            }, 2L);
        }
    }

    private void showDeathStartEffects(Player player) {
        int blind = getConfig().getInt("cinematic.blindness-ticks", 50);
        int dark = getConfig().getInt("cinematic.darkness-ticks", 50);
        if (blind > 0) player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, blind, 0, false, false, false));
        if (dark > 0) player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, dark, 0, false, false, false));

        String title = getConfig().getString("cinematic.title", "&4&lKAMU MATI");
        String subtitle = getConfig().getString("cinematic.subtitle", "&7Jiwamu telah meninggalkan dunia ini...");
        player.showTitle(net.kyori.adventure.title.Title.title(
                legacy.deserialize(title),
                legacy.deserialize(subtitle),
                net.kyori.adventure.title.Title.Times.times(
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-fade-in", 0) * 50),
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-stay", 60) * 50),
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-fade-out", 20) * 50)
                )
        ));

        String soundName = getConfig().getString("cinematic.sound", "ENTITY_WITHER_DEATH");
        try {
            player.playSound(player.getLocation(), Sound.valueOf(soundName.toUpperCase(Locale.ROOT)), 0.8f, 0.65f);
        } catch (IllegalArgumentException ignored) {
            player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.8f, 0.65f);
        }
        spawnSoulParticles(player);
    }

    private void playDeathCinematic(Player player) {
        showDeathStartEffects(player);
        player.sendMessage(legacy.deserialize("&8Sebuah kekuatan menarik jiwamu ke dimensi kehampaan..."));
    }

    private void spawnSoulParticles(Player player) {
        if (!getConfig().getBoolean("cinematic.particles", true)) return;
        Location loc = player.getLocation().add(0, 1, 0);
        player.getWorld().spawnParticle(Particle.SOUL, loc, 45, 0.8, 1.0, 0.8, 0.04);
        player.getWorld().spawnParticle(Particle.SCULK_SOUL, loc, 20, 0.5, 0.8, 0.5, 0.02);
        player.getWorld().spawnParticle(Particle.SMOKE, loc, 25, 0.6, 0.8, 0.6, 0.02);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Long expiry = punishments.get(player.getUniqueId());
        if (expiry != null && expiry > System.currentTimeMillis()) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline()) {
                    player.teleport(voidLocation());
                    player.sendMessage(legacy.deserialize("&8Kamu masih berada dalam hukuman Death Dimension."));
                }
            }, 10L);
        } else if (expiry != null) {
            punishments.remove(player.getUniqueId());
            savePunishments();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Waktu hukuman tetap berjalan saat pemain offline.
    }

    private void tickPunishments() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Long>> iterator = punishments.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Long> entry = iterator.next();
            Player player = Bukkit.getPlayer(entry.getKey());
            long remaining = entry.getValue() - now;
            if (remaining <= 0) {
                iterator.remove();
                if (player != null && player.isOnline()) {
                    player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                    player.clearTitle();
                    player.removePotionEffect(PotionEffectType.BLINDNESS);
                    player.removePotionEffect(PotionEffectType.DARKNESS);
                    player.sendMessage(legacy.deserialize("&aWaktumu di Death Dimension telah berakhir."));
                    player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.0f);
                }
            } else if (player != null && player.isOnline()) {
                String actionbar = getConfig().getString("cinematic.actionbar", "&8Kembali ke dunia dalam &c%time%");
                player.sendActionBar(legacy.deserialize(actionbar.replace("%time%", formatTime(remaining))));
                if (getConfig().getBoolean("cinematic.particles", true) && Math.random() < 0.25) {
                    player.getWorld().spawnParticle(Particle.SOUL, player.getLocation().add(0, 1, 0), 3, 0.35, 0.5, 0.35, 0.01);
                }
            }
        }
        savePunishments();
    }

    private String formatTime(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, secs);
    }

    private void loadPunishments() {
        punishments.clear();
        var section = getConfig().getConfigurationSection("punishments");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                punishments.put(UUID.fromString(key), section.getLong(key));
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("UUID hukuman tidak valid: " + key);
            }
        }
    }

    private void savePunishments() {
        getConfig().set("punishments", null);
        for (Map.Entry<UUID, Long> entry : punishments.entrySet()) {
            getConfig().set("punishments." + entry.getKey(), entry.getValue());
        }
        saveConfig();
    }

    private String color(String text) {
        return text == null ? "" : text.replace('&', '§');
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("deathdimension.admin")) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.no-permission", "&cKamu tidak punya izin.")));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.reloaded")));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Component.text("Pemain tidak ditemukan.", NamedTextColor.RED));
            return true;
        }
        if (args[0].equalsIgnoreCase("release")) {
            if (punishments.remove(target.getUniqueId()) == null) {
                sender.sendMessage(legacy.deserialize(getConfig().getString("messages.no-punishment")));
                return true;
            }
            savePunishments();
            target.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            target.clearTitle();
            target.removePotionEffect(PotionEffectType.BLINDNESS);
            target.removePotionEffect(PotionEffectType.DARKNESS);
            target.sendMessage(legacy.deserialize(getConfig().getString("messages.released")));
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.released")));
            return true;
        }
        if (args[0].equalsIgnoreCase("send")) {
            punishments.put(target.getUniqueId(), System.currentTimeMillis() + getConfig().getLong("punishment-seconds", 10800) * 1000L);
            savePunishments();
            target.teleport(voidLocation());
            playDeathCinematic(target);
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.sent")));
            return true;
        }
        sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
        return true;
    }
}
